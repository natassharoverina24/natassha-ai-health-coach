import { cn } from "@/lib/utils/cn";

export function Skeleton({ className }: { className?: string }) {
  return (
    <div
      className={cn(
        "animate-pulse rounded-control bg-ink/8",
        className,
      )}
      aria-hidden
    />
  );
}
